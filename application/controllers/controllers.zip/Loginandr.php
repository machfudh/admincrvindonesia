<?php
require APPPATH . '/libraries/REST_Controller.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Loginandr
 *
 * @author user
 */
class Loginandr extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->library('helper');
        $this->load->model('accountmodel');
        $this->load->model('authmodel');
    }

    function index_post() {

        $clientid = $this->post('clientid');
        if (empty($clientid))
            $clientid = 0;

        $token = $this->post('token');
        if (empty($token))
            $token = '';

        $username = $this->post('username');
        if (empty($username))
            $username = '';

        $password = $this->post('password');
        if (empty($password))
            $password = '';

        $clientid = $this->helper->clearInt($clientid);

        $token = $this->helper->clearText($token);
        $username = $this->helper->clearText($username);
        $password = $this->helper->clearText($password);

        if ($clientid != CLIENT_ID) {

            $this->helpel->printError(ERROR_UNKNOWN, CLIENT_ID + " Error client Id.");
        }

        $access_data = array();

        $access_data = $this->accountmodel->signin($username, $password);

        $result = array("status" => 404, "message" => FALSE, "kurir" => $access_data);
        
        if ($access_data["error"] === false) {
//
            $access_data = $this->authmodel->create($access_data['accountid'], $clientid);

            if ($access_data['error'] === false) {

                $this->accountmodel->setLastActive($access_data['accountid']);
                $access_data['data'] = array();
                $arre = array();

                array_push($arre, $this->accountmodel->getkurir($access_data['accountid']));

                $result = array("status" => 200, "message" => TRUE, "kurir" => $this->accountmodel->getkurir($access_data['accountid']));
            }
        }

//        $result = array("status" => 200, "message" => "ancur ancuran ", "data" => $arre);
//        echo $result;
        $this->authmodel->show_response($result);
        
//        echo json_encode($access_data);
//        exit;
    }
}
