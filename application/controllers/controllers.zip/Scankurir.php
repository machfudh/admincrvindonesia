<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Scankurir
 *
 * @author user
 */
class Scankurir extends CI_Controller {

    function __construct() {
        parent::__construct();
//        if ($this->session->userdata('username') == null) {
//            redirect('login');
//        }
        $this->load->model("crudmodel");
        $this->load->model("authmodel");
    }

    var $limit = 10;
    var $datainsert = 0;
    var $title = 'Courier';
    var $linkweb = 'Kurir';
    var $titlemenu = 'Data';
    var $tabel = 'scankurir';

    function index() {
        $data['title'] = $this->title;
        $data['titlemenu'] = $this->titlemenu;
        $data['main_view'] = $this->tabel . '/form';
        $data['form_action'] = site_url($this->tabel . '/scandata');
        
        
        $this->session->set_userdata('jumlahdata', 0 );
        
        $this->session->set_userdata('datakurir', 0 );
        
        $lskat = $this->db->get('kurir')->result();
        $num_row = $this->db->get('kurir')->num_rows();
        $data['listkurir'][0] = " Pilih Kurir ...";
        if ($num_row > 0) {
            foreach ($lskat as $row) {
                $data['listkurir'][$row->id_kurir] = $row->kode_kurir . " - " . $row->nama;
            }
        }

        $datate = ''; 
        $datarec = array();
        $dataview = array();
        
        $this->session->set_userdata('jumlahdata',$datate); 
        $this->session->set_userdata('jumlahrec',$datarec );
        $this->session->set_userdata('viewdata',$dataview );
        
        $this->load->view('tempfroms', $data);
    }

    function scandata() {
        $data['title'] = $this->title;
        $data['titlemenu'] = $this->titlemenu;
        $data['main_view'] = $this->tabel . '/formscan';
        $data['form_action'] = site_url($this->tabel . '/simpenarray');


        $kode_kurir = $this->input->post('lckode_kurir');

        $lcDataList = $this->crudmodel->get_data_by_id('kurir', $kode_kurir)->row();

        $datakurir = array(
            'lcid' => $lcDataList->id_kurir,
            'lckode_kurir' =>  $lcDataList->kode_kurir,
            'lcnama' => $lcDataList->nama,
            'lcalamat' => $lcDataList->alamat    
        );
        
        $this->session->set_userdata('datakurir', $datakurir );
     
        $data['data']['lcid'] = $lcDataList->id_kurir;
        $data['data']['lckode_kurir'] = $lcDataList->kode_kurir;
        $data['data']['lcnama'] = $lcDataList->nama;
        $data['data']['lcalamat'] = $lcDataList->alamat;

      

        $this->load->view('tempfroms', $data);
    }

    function simpenarray() {
        $data['title'] = $this->title;
        $data['titlemenu'] = $this->titlemenu;
        $data['main_view'] = $this->tabel . '/formscan';
        $data['form_action'] = site_url($this->tabel . '/savearray');
        
//        if(isset($_POST['submit'])){
//            echo 'Okeh ...... masuk bos ....';
//          
//            
//            
//        }

        $kode_kurir = $this->input->post('lcid');

//        $this->db->where('id_' . $this->tabel, $para2);
//        $this->db->get($this->tabel);

        $lcDataList = $this->crudmodel->get_data_by_id('kurir', $kode_kurir)->row();

//        $data['data']['lcid'] = $lcDataList->id_kurir;
//        $data['data']['lckode_kurir'] = $lcDataList->kode_kurir;
//        $data['data']['lcnama'] = $lcDataList->nama;
//        $data['data']['lcalamat'] = $lcDataList->alamat; 
        
//        $datate = ''; 
//        $datarec = '';
//        
//        $this->session->set_userdata('jumlahdata',$datate); 
//        $this->session->set_userdata('jumlahrec',$datarec ); 

        $this->load->view('tempfroms', $data);
    }

    function simpendata() {
        
//        $data['form_action'] = site_url($this->tabel . '/savearray');

        $dataisian = $this->input->post('lcseqno');
        $this->db->where('seqno', $dataisian);
        $barang = $this->db->get('barang');
        
        $viewkurir = '';
        $databarang = $barang->row();
        $isidata = $barang->num_rows();
        $arry = array();
        $arryview = array();
        $viewkurir = '';
        $datate = $this->session->userdata('jumlahdata');
        $datarec = $this->session->userdata('jumlahrec');
        $dataview = $this->session->userdata('viewdata');
        
        if ($isidata > 0) {
            
            if($databarang->id_stati == 0  && $databarang->id_statret == 0 ){
//        $arry = array();
//        $arryview = array();
//        $viewkurir = '';
//        $datate = $this->session->userdata('jumlahdata');
//        $datarec = $this->session->userdata('jumlahrec');
//        $dataview = $this->session->userdata('viewdata');
//        $datarec = $arry;
//        $isiarr = count($datarec);
//        echo $isiarr;
//        $hasil = null;
        if( count($datarec) == 0 ){
            
//            $data_bar['id_kurir'] = $this->session->userdata('datakurir')['lcid'];
//            $data_bar['waktu_ambil'] = time();
//            $data_bar['id_statusshipp'] = 1 ;
//            $this->db->where('id_barang', $databarang->id_barang);
//            $this->db->update('barang', $data_bar);
            
//            echo "Masih Kosong ".$datarec;
            array_push($arry, $databarang->id_barang);
            array_push($arryview, "#".$databarang->seqno ."#".$databarang->nama);
            $datarec = $arry;
            $dataview = $arryview;
//            print_r($arry);
            $viewkurirx = $dataview[0];
            $datate = $datate + 1 ; 
            $this->session->set_userdata('jumlahdata', $datate ); 
            $this->session->set_userdata('jumlahrec', $datarec );
            $this->session->set_userdata('viewdata', $dataview );
            
        }else{
//            echo "Sudah Di isi  ".$datarec;
            $arry = $datarec; 
            $arryview = $dataview;
        
            $hasil = array_search($databarang->id_barang,$arry);
//            echo $hasil;
//        }
//        
        if( $hasil == null ){
//            
//            $data_bar['id_kurir'] = $this->session->userdata('datakurir')['lcid'];
//            $data_bar['waktu_ambil'] = time();
//            $data_bar['id_statusshipp'] = 1 ;
//            $this->db->where('id_barang', $databarang->id_barang);
//            $this->db->update('barang', $data_bar);
//            
//            }
        
//           if ($hasil != 0) {  
            array_push($arry, $databarang->id_barang);
            array_push($arryview, "#".$databarang->seqno ."#".$databarang->nama);
            $datarec = $arry;
            $dataview = $arryview;
//            print_r($arry);
//            $viewkurirx = $dataview[0];
            
//            $datarec = $arry;
//            print_r($arry);
            
            $datate = $datate + 1 ; 
            $this->session->set_userdata('jumlahdata', $datate ); 
            $this->session->set_userdata('jumlahrec', $datarec );
            $this->session->set_userdata('viewdata', $dataview );
            $viewkurirx = '';
            $i=0;        
//            for( $i=0; $i < count($datarec);$i++){
//               $viewkurirx .= $datarec[$i] ;
//            }

        }   
        $viewkurirx = '';
//        for( $i=0; $i < count($datarec);$i++){
//               $viewkurirx .= $dataview[$i]+"<br/>" ;
//            }
        
            }
        }   
        }
        $viewkurir .= '<div class="mail-item d-flex pd-y-10 pd-x-20">';
        $viewkurir .= '<div class="mg-l-30">';
        $viewkurir .= '    <h3 class="tx-14"> Total Data : ' . $this->session->userdata('jumlahdata') . '</h3>';
        $datarec = $this->session->userdata('jumlahrec');
//        foreach ( $datarec as $row ){
        if(count($datarec) > 0) {
        for( $i=0; $i < count($datarec);$i++){
            $viewkurir .= '    <h6 class="tx-14"><a href="" class="tx-inverse"> ' . $dataview[$i] . ' </a></h6>';
//            $viewkurirx .= $dataview[$i]+"<br/>" ;
            }
        }  
//        $viewkurir .= '    <h6 class="tx-14"><a href="" class="tx-inverse"> ' . $viewkurirx . ' </a></h6>';
//        }
//        $viewkurir .= '    <p class="tx-13 mg-b-10">' . $databarang->alamat1 .$data_bar['id_kurir']. '</p>';
        $viewkurir .= '</div>';
        $viewkurir .= '</div>';
        

        echo $viewkurir;
    }
    
    function savearray(){
        $datarec = $this->session->userdata('jumlahrec');
        
        if (count($datarec) > 0){
            for( $i=0; $i < count($datarec);$i++){
                
            $data_bar['id_kurir'] = $this->session->userdata('datakurir')['lcid'];
            $data_bar['waktu_ambil'] = time();
            $data_bar['id_statusshipp'] = 1 ;
            $this->db->where('id_barang', $datarec[$i]);
            $this->db->update('barang', $data_bar);
            }
        }
        
        redirect($this->tabel);
    }
            
    
    
    

    function getviewkurir() {
        $kode_kurir = $_POST['prov'];
        $viewkurir = '';
        if ($kode_kurir != 0) {
            $this->db->where('id_kurir', $kode_kurir);
            $lskurir = $this->db->get('kurir')->row();

            if ($lskurir->id_kurir != 0) {

                $viewkurir .= '<div class="mail-item d-flex pd-y-10 pd-x-20">';
                $viewkurir .= '<div class="pd-t-5"><img src="' . base_url() . 'uploads/kurir_image/' . $lskurir->photokurir . '" class="wd-48 rounded-circle" alt=""></div>';
                $viewkurir .= '<div class="mg-l-30">';
                $viewkurir .= '    <h6 class="tx-14"><a href="" class="tx-inverse"> ' . $lskurir->nama . ' </a></h6>';
                $viewkurir .= '    <p class="tx-13 mg-b-10">' . $lskurir->userlogin . '</p>';
                $viewkurir .= '</div>';
                $viewkurir .= '</div>';
            }
        }
        echo $viewkurir;
    }

}
