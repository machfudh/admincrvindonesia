<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Reportexcel
 *
 * @author user
 */
class Reportexcel extends CI_Controller {

    function __construct() {
        parent::__construct();
//        }
        $this->load->model("crudmodel");
        $this->load->model("authmodel");
    }

    function cetakexcel($code) {

        $objPHPexcel = PHPExcel_IOFactory::load(APPPATH . "../excel/report.xls");

        $objWorksheet = $objPHPexcel->getActiveSheet();

        if ($code == 100) {
            $kurir = $this->session->userdata('reinkurir');
            $shipp = $this->session->userdata('reinshipp');
            $dawal = $this->session->userdata('reindawal');
            $dakhir = $this->session->userdata('reindakhir');
            $tanggalReport = $this->session->userdata('reinJudul');

            if ($this->session->userdata('caridata') == 'crinReport') {
                $kurir = $this->session->userdata('reinkurir');
                $shipp = $this->session->userdata('reinshipp');
                $dawal = $this->session->userdata('reindawal');
                $dakhir = $this->session->userdata('reindakhir');
                $tanggalReport = $this->session->userdata('reinJudul');
            } else {
                $kurir = 0;
                $shipp = 0;
                $tgl = date('Y/m/d');
                $dawal = time($tgl);
                $dakhir = time($tgl);
                $tanggalReport = "";
            }
             if( $shipp == 2 ){
                $reportdata = $this->crudmodel->count_reportinpro2('v_baranginpro', $dawal, $dakhir, $kurir, $shipp)->result();
                $reportnumrow = $this->crudmodel->count_reportinpro2('v_baranginpro', $dawal, $dakhir, $kurir, $shipp)->num_rows();
             }else{
                 $reportdata = $this->crudmodel->count_reportinpro3('v_baranginpro', $dawal, $dakhir, $kurir, $shipp)->result();
                 $reportnumrow = $this->crudmodel->count_reportinpro3('v_baranginpro', $dawal, $dakhir, $kurir, $shipp)->num_rows();
             }
        } else {
            $kurir = $this->session->userdata('rekurir');
            $shipp = $this->session->userdata('reshipp');
            $dawal = $this->session->userdata('redawal');
            $dakhir = $this->session->userdata('redakhir');
            $tanggalReport = $this->session->userdata('reJudul');

            if ($this->session->userdata('caridata') == 'crReport') {
                $kurir = $this->session->userdata('rekurir');
                $shipp = $this->session->userdata('reshipp');
                $dawal = $this->session->userdata('redawal');
                $dakhir = $this->session->userdata('redakhir');
                $tanggalReport = $this->session->userdata('reJudul');
            } else {
                $kurir = 0;
                $shipp = 0;
                $tgl = date('Y/m/d');
                $dawal = time($tgl);
                $dakhir = time($tgl);
                $tanggalReport = "";
            }
            $reportdata = $this->crudmodel->count_report('v_barang', $dawal, $dakhir, $kurir, $shipp)->result();
            $reportnumrow = $this->crudmodel->count_report('v_barang', $dawal, $dakhir, $kurir, $shipp)->num_rows();
        }

        if ($reportnumrow > 0) {
            $objWorksheet->setCellValue('B3', "Report " . $tanggalReport);
            $no = 1;
            $nbaris = 6;
            foreach ($reportdata as $row) {
                $objWorksheet->setCellValue('B' . $nbaris, $no);
                $objWorksheet->setCellValue('C' . $nbaris, $row->seqno);
                $objWorksheet->setCellValue('D' . $nbaris, $row->noref);
                $objWorksheet->setCellValue('E' . $nbaris, $row->nama);
                $objWorksheet->setCellValue('F' . $nbaris, $row->alamat1);
                $objWorksheet->setCellValue('G' . $nbaris, $row->alamat2);
                $objWorksheet->setCellValue('H' . $nbaris, $row->alamat3);
                $objWorksheet->setCellValue('I' . $nbaris, $row->kota);
                $objWorksheet->setCellValue('J' . $nbaris, trim($row->tgl_upload != 0 ? date("d-m-Y", $row->tgl_upload) : ""));
                $objWorksheet->setCellValue('K' . $nbaris, trim($row->type));
                $objWorksheet->setCellValue('L' . $nbaris, trim($row->serv_type));
                $objWorksheet->setCellValue('M' . $nbaris, trim($row->kurirnama));
                $objWorksheet->setCellValue('N' . $nbaris, trim($row->statusketerangan));
                $objWorksheet->setCellValue('O' . $nbaris, trim($row->waktu_diterima != 0 ? date("d-m-Y", $row->waktu_diterima) : "" ));
                $objWorksheet->setCellValue('P' . $nbaris, trim($row->penerima));
                $objWorksheet->setCellValue('Q' . $nbaris, trim($row->waktu_diterima != 0 ? $row->statiket : $row->statretket));
                $objWorksheet->setCellValue('R' . $nbaris, trim($row->waktu_dikembalikan != 0 ? date("d-m-Y", $row->waktu_dikembalikan) : ""));
                $objWorksheet->setCellValue('S' . $nbaris, trim($row->catatan));

                $no++;
                $nbaris++;
            }
        }


        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="report.xls"');
        header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPexcel, "Excel2007");
        $objWriter->save('php://output');
        $objPHPexcel->disconnectWorksheets();
        unset($objPHPexcel);
    }

}
