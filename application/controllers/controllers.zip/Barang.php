<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Barang
 *
 * @author user
 */
class Barang extends CI_Controller {

    function __construct() {
        parent::__construct();
//        }
        $this->load->model("crudmodel");
        $this->load->model("authmodel");
    }

    var $limit = 10;
    var $title = 'Upload Data';
    var $linkweb = 'barang';
    var $titlemenu = 'Data';
    var $tabel = 'barang';

    function index() {
        $this->listdata();
    }

    function listdata($offset = 0) {
        ;
//        $data['menu'] = $this->Callmenu->menu();
        $data['title'] = $this->title;
        $data['titlemenu'] = $this->titlemenu;
        $data['main_view'] = 'tabel';
        $data['form_action'] = site_url($this->linkweb . '/searchdata');
        $data['search'] = array('seqno' => 'Seq No',
            'noref' => 'No reff',
            'nama' => 'Name',
            'alamat1' => 'Addresss',
            'statusketerangan' => 'Status',
            'kurir' => 'Courier',
        );
        $data['sfocus'] = 'kode_kurir';
        $finds = $this->session->userdata('finds');
        $findt = $this->session->userdata('findt');

        if ($this->session->userdata('caridata') == 'cr' . $this->tabel) {
            $finds = $this->session->userdata('finds');
            $findt = $this->session->userdata('findt');
        } else {
            $finds = '';
            $findt = '';
        }
        $uri_segment = 3;
        $offset = $this->uri->segment($uri_segment);

        $mDatalist = $this->crudmodel->list_data($this->tabel, $this->limit, $offset, $finds, $findt)->result();
        $numRow = $this->crudmodel->count_data($this->tabel);
        if ($numRow > 0) {
            $config['base_url'] = site_url('barang/listdata');
            $config['total_rows'] = $numRow;
            $config['per_page'] = $this->limit;
            $config['uri_segment'] = $uri_segment;
            $config['first_link'] = '<i class="fa fa-angle-double-left"></i>';
            $config['first_tag_open'] = ' <li class="page-item">';
            $config['first_tag_close'] = '</li>';
            $config['last_link'] = '<i class="fa fa-angle-double-right"></i>';
            $config['last_tag_open'] = '<li class="page-item">';
            $config['last_tag_close'] = '</li>';
            $config['next_link'] = '<i class="fa fa-angle-right"></i>';
            $config['next_tag_open'] = '<li class="page-item">';
            $config['next_tag_close'] = '</li>';
            $config['prev_link'] = '<i class="fa fa-angle-left"></i>';
            $config['prev_tag_open'] = '<li class="page-item">';
            $config['prev_tag_close'] = '</li>';
            $config['cur_tag_open'] = '<li class="page-item">';
            $config['cur_tag_close'] = '</li>';
            $config['num_tag_open'] = '<li class="page-item">';
            $config['num_tag_close'] = '</li>';
            $this->pagination->initialize($config);
            $data['pagination'] = ' Total Record ' . $numRow . "&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;". $this->pagination->create_links();
            $tmpl = array('table_open' => '<table class="table table-hover table-bordered mg-b-0">',
                'heading_row_start' => '<thead class="bg-info"><tr>',
                'heading_row_end' => '</tr></thead>',
                'heading_cell_start' => '<th>',
                'heading_cell_end' => '</th>',
                'row_start' => '<tr>',
                'row_end' => '</tr>',
                'row_alt_start' => '<tr>',
                'row_alt_end' => '</tr>'
            );
            $this->table->set_template($tmpl);
            $this->table->set_heading(
                    array('data' => 'No', 'style' => 'width:3%'), 
                    array('data' => 'Seg No', 'style' => 'width:10%'), 
                    array('data' => 'Noref', 'style' => 'width:10%'), 
                    array('data' => 'Name'), 
                    array('data' => 'Address', 'style' => 'width:30%'), 
                    array('data' => 'Status', 'style' => 'width:10%'), 
                    array('data' => 'Courier', 'style' => 'width:10%'));
            $i = 0 + $offset;
            foreach ($mDatalist as $sDataList) {
                if ($this->session->userdata('access') == '257') {
                    $this->table->add_row(++$i, anchor('report/viewbarang/' . $sDataList->id_barang, $sDataList->seqno), $sDataList->noref, $sDataList->nama, $sDataList->alamat1, $sDataList->statusketerangan, $sDataList->kurirnama 
//                            anchor($this->tabel . '/action/edit/' . $sDataList->id_barang, '<i class="icon ion-edit"></i>', array('class' => "edit-row", 'data-original-title' => 'Edit')) . "&nbsp&nbsp&nbsp" .
//                            anchor($this->tabel . '/action/delete/' . $sDataList->id_barang, '<i class="icon ion-trash-a"></i>', array('class' => "delete-row", 'data-original-title' => 'Delete', 'onclick' => "return confirm('Anda yakin akan menghapus data ini?')"))
                    );
                } 
//                else if ($this->session->userdata('access') == '100') {
//                    $this->table->add_row(++$i, '<img src="' . base_url() . 'uploads/kurir_image/' . $sDataList->photokurir . '" class="wd-40" alt="Image">', anchor($this->tabel . '/action/edit/' . $sDataList->id_kurir, $sDataList->kode_kurir), $sDataList->nama, $sDataList->ketetangan, $sDataList->userlogin, $sDataList->nomor_kend
//                    );
//                }
            }

            $data['table'] = $this->table->generate();
        } else {
            $data['message'] = 'Tidak ditemukan satupun data !';
        }
        $data['link'] = array('link_add' => anchor($this->tabel . '/action/add', '<div><i class="fa fa-plus"></i></div>', 'class="btn btn-outline-success btn-icon mg-r-5"'),
            'link_print' => anchor($this->tabel . '/action/add', 'Print', 'class="btn btn-success btn-small hidden-phone"'));
        $this->load->view('templates', $data);
    }

    function searchdata() {
        $this->session->set_userdata('caridata', 'cr' . $this->tabel);
        $this->session->set_userdata('finds', $this->input->post('lcfinds'));
        $this->session->set_userdata('findt', $this->input->post('lcfindt'));
        redirect($this->tabel);
    }

    function action($para1 = '') {
//        $data['menu'] = $this->Callmenu->menu();
        $data['title'] = $this->title;

        if ($para1 == 'save') {
            $salt = $this->authmodel->generateSalt(10);
            $timeinsert = time();
            $path = $_FILES['img']['name'];
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            $data_banner['databarang'] = "barang". '.' . $ext;
            $this->crudmodel->file_txt("img", "barang", $salt, '', 'no', '.' . $ext);

            $StudentDetails = base_url() . 'uploads/barang_data/' . $data_banner['databarang'];

            $file = fopen($StudentDetails, "r");
            $StudentDetails = array();

            while (!feof($file)) {
                $StudentDetails[] = fgets($file);
            }

            $waktu_upload = time();
            fclose($file);
            if (!empty($StudentDetails)) {
                foreach ($StudentDetails as $lines => $value):
//                    print 'No : ' . $lines . ': ' . $value . "</br>";
                    $hasilex = explode('","', $value);
//                    $hasilex = explode(",", $value);
                    if (!empty($hasilex)) {
                        foreach ($hasilex as $linesxx => $valuexx):
//                            print 'Noxx : ' . $linesxx . ': ' . $valuexx . "</br>";
                        endforeach;
                    

                    if ($lines > 0) {
                        if ($hasilex[0] != null) {
                            $seqno = preg_replace("/[^a-zA-Z0-9]/", "", $hasilex[0]);
                            $arr = explode('/', $hasilex[8]);
                            $newDate = $arr[2].'/'.$arr[1].'/'.$arr[0];
                            $dtTtime = strtotime($newDate);
//                            $this->db->where('seqno', $seqno);
//                            $databarang = $this->db->get($this->tabel);
//                            if ($databarang->num_rows() = 0) {
                                $datatabel = array(
                                    'seqno' => $seqno,
                                    'noref' => $hasilex[1],
                                    'nama' => $hasilex[2],
                                    'alamat1' => $hasilex[3],
                                    'alamat2' => $hasilex[4],
                                    'alamat3' => $hasilex[5],
                                    'kota' => $hasilex[6],
                                    'kodepos' => $hasilex[7],
                                    'tgl_upload' => $dtTtime,
                                    'type' => $hasilex[9],
                                    'serv_type' => $hasilex[10],
                                    'harga' => preg_replace("/[^a-zA-Z0-9]/", "", $hasilex[11]),
                                    'waktu_upload' =>$waktu_upload,
                                );

                               $this->db->where('seqno', $seqno);
                               $databarang = $this->db->get($this->tabel);
                               if ($databarang->num_rows() === 0) {
                                $this->db->insert('barang', $datatabel);
                               }
                            }
                        }
                    }
                endforeach;
            }

            redirect($this->tabel);
        } elseif ($para1 == 'add') {
            $data['titlemenu'] = $this->titlemenu;
            $data['main_view'] = $this->tabel . '/formupload';
            $data['form_action'] = site_url($this->tabel . '/action/save/');
            $this->load->view('tempfroms', $data);
        } 
    }

}
