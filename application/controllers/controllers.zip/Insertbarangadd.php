<?php
require APPPATH . '/libraries/REST_Controller.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Insertbarangadd
 *
 * @author user
 */
class Insertbarangadd extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->library('helper');
        $this->load->model('accountmodel');
        $this->load->model('authmodel');
    }

    function index_post() {

        $clientid = $this->post('clientid');
        if (empty($clientid))
            $clientid = 0;
        
        $sharedkey = $this->post('sharedkey');
        if (empty($sharedkey))
            $sharedkey = '';
        
        $segno = $this->post('segno');
        if (empty($segno))
            $segno = '';
        
            $noref= $this->post('noref');
        if (empty($noref))
            $noref = '';
        
        $nama = $this->post('nama');
        if (empty($nama))
            $nama = '';
        
        
        $alamat1 = $this->post('alamat1');
        if (empty($alamat1))
            $alamat1 = '';
        
//        
//        $tgl_upload = $this->post('tgl_upload');
//        if (empty($tgl_upload))
//            $tgl_upload = '';
        
        $type = $this->post('type');
        if (empty($type))
            $type = '';
        
        
        $serv_type = $this->post('serv_type');
        if (empty($serv_type))
            $serv_type = '';
        
            
        $harga = $this->post('harga');
        if (empty($harga))
            $harga = '';
 
        
        $clientid = $this->helper->clearInt($clientid);
//        $sharedkey = $this->helper->clearText($sharedkey);
//        $segno = $this->helper->clearText($segno);

//        if ($clientid != CLIENT_ID) {
//            $this->helper->printError(ERROR_UNKNOWN, CLIENT_ID + " Error client Id.");
//        }

        if($sharedkey == "BANK@d0e5bec1734e5cd99003dfc36a107e09" ){
        $arre = array();
//        $this->db->where("seqno",$segno);
//        $data = $this->db->get('v_barang');
//        $datares = $data->result();
         $timeinsert = time();
                    $datatabel = array(
                                    'seqno' => $segno,
                                    'noref' => $noref,
                                    'nama' => $nama,
                                    'alamat1' => $alamat1,
                                    'tgl_upload' => $timeinsert,
                                    'type' => $type,
                                    'serv_type' => $serv_type,
                                    'harga' => $harga,
                                    'waktu_upload' =>$timeinsert,
                                );
        
        $data = $this->db->insert('barang', $datatabel);
           

        if ($data) {
            $tempdata = array(
              "status" => true,
                    "ket" => "Data Berhasil disimpan");
        }else{
            $tempdata = array(
              "status" => false,
                    "ket" => "SegNo Not Found");  
        }

//        $result = array("status" => 200, "message" => TRUE, "record" => $data->num_rows(),"dokumen" => $arre);
        }else{
          $tempdata = array(
              "status" => false,
                    "ket" => "Shared Key Error");  
            
//        $result = array("status" => 200, "message" => FALSE, "dokumen" => $arre);   
        }
        
        $this->authmodel->show_response($tempdata);
    }
}
