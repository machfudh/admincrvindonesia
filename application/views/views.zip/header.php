<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>Card Delivery Application</title>

<meta content="Nusa Pro Media Solusi" name="description" />
<meta content="Moh Machfudh" name="author" />

<!-- vendor css -->
<link href="<?php echo base_url() . 'assets/lib/font-awesome/css/font-awesome.css'; ?>" rel="stylesheet">
<link href="<?php echo base_url() . 'assets/lib/Ionicons/css/ionicons.css'; ?>" rel="stylesheet">
<link href="<?php echo base_url() . 'assets/lib/perfect-scrollbar/css/perfect-scrollbar.css'; ?>" rel="stylesheet">
<link href="<?php echo base_url() . 'assets/lib/jquery-toggles/toggles-full.css'; ?>" rel="stylesheet">
<link href="<?php echo base_url() . 'assets/lib/rickshaw/rickshaw.min.css'; ?>" rel="stylesheet">


<link href="<?php echo base_url() . 'assets/lib/highlightjs/github.css'; ?>" rel="stylesheet">
<link href="<?php echo base_url() . 'assets/lib/select2/css/select2.min.css'; ?>" rel="stylesheet">
<link href="<?php echo base_url() . 'assets/lib/spectrum/spectrum.css'; ?>" rel="stylesheet">

<!-- Amanda CSS -->
<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/amanda.css'; ?>">

<link rel="shortcut icon" href="<?php echo base_url() .'uploads/sag.ico';?>">