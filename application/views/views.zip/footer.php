<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  moh. machfudh
 */
?>

<script src="<?php echo base_url() . 'assets/lib/jquery/jquery.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/popper.js/popper.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/bootstrap/bootstrap.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/jquery-toggles/toggles.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/d3/d3.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/rickshaw/rickshaw.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/Flot/jquery.flot.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/Flot/jquery.flot.pie.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/Flot/jquery.flot.resize.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/flot-spline/jquery.flot.spline.js'; ?>"></script>


<script src="<?php echo base_url() . 'assets/lib/highlightjs/highlight.pack.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/select2/js/select2.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/lib/spectrum/spectrum.js'; ?>"></script>

<script src="<?php echo base_url() . 'assets/js/amanda.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/js/ResizeSensor.js'; ?>"></script>


