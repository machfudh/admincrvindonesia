<div class="col-xl-8">
    <div class="card pd-20 pd-sm-40 form-layout form-layout-4">
        <h6 class="card-body-title"><?php echo $title ?></h6>
        <?php $datakurirx = $this->session->userdata('datakurir'); ?>
        <p class="mg-b-20 mg-sm-b-30"><?php echo $datakurirx['lckode_kurir'] ."  ".$datakurirx['lcnama']; ?></p>
        
        
        <form name="kategoriform" id="getBarcode" method="post" action="<?php echo $form_action; ?>" onsubmit="return  fromSubmit();">
            <div class="row">
                <label class="col-sm-4 form-control-label">Seqno: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcseqno" type="text" placeholder="Scan barcode" autofocus >
                </div>
            </div><!-- row -->
            
            <input type="hidden" name="lcid"  value="<?php echo set_value('lcid', isset($data['lcid']) ? $data['lcid'] : ''); ?>" />
            <div class="form-layout-footer mg-t-30">
                <!--<button type="submit" name="submit" class="btn btn-info mg-r-5">Save</button>-->
                <a href="savearray" class="btn btn-info mg-r-5"><div>Simpan</div></a>
                <h3 id="success"></h3>
            </div><!-- form-layout-footer -->
        </form>
    </div><!-- card -->
</div><!-- col-6 -->



