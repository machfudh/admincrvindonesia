<div class="am-sideleft">
            <ul class="nav am-sideleft-tab">
                <li class="nav-item">
                    <a href="#mainMenu" class="nav-link active"><i class="icon ion-ios-home-outline tx-24"></i></a>
                </li>
                <li class="nav-item">
                    <a href="#emailMenu" class="nav-link"><i class="icon ion-ios-email-outline tx-24"></i></a>
                </li>
                <li class="nav-item">
                    <a href="#chatMenu" class="nav-link"><i class="icon ion-ios-chatboxes-outline tx-24"></i></a>
                </li>
                <li class="nav-item">
                    <a href="#settingMenu" class="nav-link"><i class="icon ion-ios-gear-outline tx-24"></i></a>
                </li>
            </ul>

            <div class="tab-content">
                <div id="mainMenu" class="tab-pane active">
                    <ul class="nav am-sideleft-menu">
                        <li class="nav-item">
                            <a href="<?php echo base_url() .'index.php/welcome' ?>" class="nav-link">
                                <i class="icon ion-ios-home-outline"></i>
                                <span>Dashboard</span>
                            </a>
                        </li><!-- nav-item -->
                        <li class="nav-item">
                            <a href="" class="nav-link with-sub">
                                <i class="icon ion-ios-gear-outline"></i>
                                <span>Master</span>
                            </a>
                            <ul class="nav-sub">
                                <li class="nav-item"><?php echo anchor('kurir','Courier','class="nav-link"'); ?></li>
                                <li class="nav-item"><?php echo anchor('stati','Success Status','class="nav-link"'); ?></li>
                                <li class="nav-item"><?php echo anchor('statret','Return Status','class="nav-link"'); ?></li>
                                <li class="nav-item"><?php echo anchor('statusshipp','Shipping Status','class="nav-link"'); ?></li>
                            </ul>
                        </li><!-- nav-item -->
                        <li class="nav-item">
                            <a href="" class="nav-link with-sub">
                                <i class="icon ion-ios-filing-outline"></i>
                                <span>Data</span>
                            </a>
                            <ul class="nav-sub">
                                <li class="nav-item"><?php echo anchor('barang','Upload Data','class="nav-link"'); ?></li>
                                <li class="nav-item"><?php echo anchor('scankurir','Courier Delivery Zone','class="nav-link"'); ?></li>
                            </ul>
                        </li><!-- nav-item -->  
                        <li class="nav-item">
                            <a href="" class="nav-link with-sub">
                                <i class="icon ion-ios-analytics-outline"></i>
                                <span>Report</span>
                            </a>
                            <ul class="nav-sub">
                                <li class="nav-item"><?php echo anchor('report','Report','class="nav-link"'); ?></li>
                            </ul>
                        </li><!-- nav-item -->
                        <li class="nav-item">
                            <a href="" class="nav-link with-sub">
                                <i class="icon ion-ios-navigate-outline"></i>
                                <span>User</span>
                            </a>
                            <ul class="nav-sub">
                                <li class="nav-item"><?php echo anchor('user','User','class="nav-link"'); ?></li>
                            </ul>
                        </li><!-- nav-item -->
                     </ul>
                </div><!-- #mainMenu -->
                <div id="emailMenu" class="tab-pane">
                   
                </div><!-- #emailMenu -->
                <div id="chatMenu" class="tab-pane">
                    
                </div><!-- #chatMenu -->
                <div id="settingMenu" class="tab-pane">
             
                </div><!-- #settingMenu -->
            </div><!-- tab-content -->
        </div><!-- am-sideleft -->