<div class="col-xl-8">
    <div class="card pd-20 pd-sm-40 form-layout form-layout-4">
        <h6 class="card-body-title"><?php echo $title ?></h6>
        <p class="mg-b-20 mg-sm-b-30">Keterangan Input</p>
        <form name="kategoriform" enctype="multipart/form-data" id="selectForm" method="post" action="<?php echo $form_action; ?>">
            <div class="row">
                <label class="col-sm-4 form-control-label">kode Kurir: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lckode_kurir" type="text" placeholder="Kode Kurir"
                           value='<?php echo set_value('lckode_kurir', isset($data['lckode_kurir']) ? $data['lckode_kurir'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">Nama: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcnama" type="text" placeholder="Nama"
                           value='<?php echo set_value('lcnama', isset($data['lcnama']) ? $data['lcnama'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">Alamat: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcalamat" type="text" placeholder="Alamat"
                           value='<?php echo set_value('lcalamat', isset($data['lcalamat']) ? $data['lcalamat'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">Telpon 1: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lctelp1" type="text" placeholder="Telpon"
                           value='<?php echo set_value('lctelp1', isset($data['lctelp1']) ? $data['lctelp1'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">Telpon 2: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lctelp2" type="text" placeholder="Telpon 2"
                           value='<?php echo set_value('lctelp2', isset($data['lctelp2']) ? $data['lctelp2'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">Tgl Masuk: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lctgl_masuk" type="text" placeholder="Tanggal Masuk"
                           value='<?php echo set_value('lctgl_masuk', isset($data['lctgl_masuk']) ? $data['lctgl_masuk'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">Pendidikan: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcpendidikan" type="text" placeholder="Pendidikan"
                           value='<?php echo set_value('lcpendidikan', isset($data['lcpendidikan']) ? $data['lcpendidikan'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">Rute : <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcrute" type="text" placeholder="Rute"
                           value='<?php echo set_value('lcrute', isset($data['lcrute']) ? $data['lcrute'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">user login: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcuserlogin" type="email" placeholder="Email Address"
                           value='<?php echo set_value('lcuserlogin', isset($data['lcuserlogin']) ? $data['lcuserlogin'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">user password: <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcuserpass" type="text" placeholder="User Password"
                           value='<?php echo set_value('lcuserpass', isset($data['lcuserpass']) ? $data['lcuserpass'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row">
                <label class="col-sm-4 form-control-label">No Kendaraan : <span class="tx-danger">*</span></label>
                <div class="col-sm-8 mg-t-10 mg-sm-t-0">
                    <input class="form-control" id="nama" name="lcnomor_kend" type="text" placeholder="No. Kendaraan"
                           value='<?php echo set_value('lcnomor_kend', isset($data['lcnomor_kend']) ? $data['lcnomor_kend'] : ''); ?>'>
                </div>
            </div><!-- row -->
            <div class="row mg-t-20">
                <label class="col-sm-4 form-control-label">Photo: <span class="tx-danger">*</span></label>
                <div class="col-lg-3 mg-t-40 mg-lg-t-0">
                    <label class="custom-file">
                        <input type="file"  name="img" accept="image">
                    </label>
                </div>
            </div>

            <div class="row mg-t-20">
                <?php
                if (isset($data['lcphoto'])) {
                    ?>
                    <img src="<?php echo base_url(); ?>uploads/kurir_image/<?php echo $data['lcphoto']; ?>" width="20%" id='blah' />  
                    <?php
                } else {
                    ?>
                    <img src="<?php echo base_url(); ?>uploads/kurir_image/default.jpg" width="20%" alt="" id='blah' />
                    <?php
                }
                ?> 
            </div>
            
            <input type="hidden" name="lcid"  value="<?php echo set_value('lcid', isset($data['lcid']) ? $data['lcid'] : ''); ?>" />
            <div class="form-layout-footer mg-t-30">
                <button type="submit" class="btn btn-info mg-r-5">Save</button>
                <button class="btn btn-secondary">Cancel</button>
            </div><!-- form-layout-footer -->
        </form>
    </div><!-- card -->
</div><!-- col-6 -->



