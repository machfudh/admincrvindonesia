<?php

require APPPATH . '/libraries/REST_Controller.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Isistatusandr
 *
 * @author user
 */
class Isistatusandr extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->library('helper');
        $this->load->model('accountmodel');
        $this->load->model('authmodel');
    }

    function index_post() {

        $clientid = $this->post('clientid');
        if (empty($clientid))
            $clientid = 0;

        $token = $this->post('token');
        if (empty($token))
            $token = '';

        $id_barang = $this->post('id_barang');
        if (empty($id_barang))
            $id_barang = '';

        $id_stati = $this->post('id_stati');
        if (empty($id_stati))
            $id_stati = '';

        $id_statret = $this->post('id_statret');
        if (empty($id_statret))
            $id_statret = '';

        $latitut = $this->post('latitut');
        if (empty($latitut))
            $latitut = '';

        $longtitut = $this->post('longtitut');
        if (empty($longtitut))
            $longtitut = '';

        $penerima = $this->post('penerima');
        if (empty($penerima))
            $penerima = '';

        $catatan = $this->post('catatan');
        if (empty($catatan))
            $catatan = '';

        $sukseskode = $this->post('sukseskode');
        if (empty($sukseskode))
            $sukseskode = '';

        $clientid = $this->helper->clearInt($clientid);
        $id_stati = $this->helper->clearInt($id_stati);
        $id_statret = $this->helper->clearInt($id_statret);
//        $latitut = $this->helper->clearInt($latitut);
//        $longtitut = $this->helper->clearInt($longtitut);
        $sukseskode = $this->helper->clearInt($sukseskode);
        $id_barang = $this->helper->clearInt($id_barang);

//        $token = $this->helper->clearText($token);
        $penerima = $this->helper->clearText($penerima);
        $catatan = $this->helper->clearText($catatan);

        if ($clientid != CLIENT_ID) {

            $this->helpel->printError(ERROR_UNKNOWN, CLIENT_ID + " Error client Id.");
        }

        $getidfromtoken = $this->authmodel->tokentoid($token);
        $message = FALSE;

        $tempdata = array();
        if ($getidfromtoken != 0 && $id_barang != "") {
//            $message =  "okeh dah ada token nya ... !";
            $message = $this->authmodel->insertstatus($id_barang, $id_stati, $id_statret, $latitut, $longtitut, $penerima, $catatan, $sukseskode);
            if ($message) {
                $this->db->where('id_barang', $id_barang);
                $dataStatus = $this->db->get('v_barang');
                if ($dataStatus->num_rows() > 0) {
                    $row = $dataStatus->row();
                    $lcwaktu_diterima = " ";
                    $lcwaktu_dikembalikan = " ";
                    if ($row->waktu_diterima != 0) {
                        $lcwaktu_diterima = date("d-m-Y H:i:s", $row->waktu_diterima);
                    }
                    if ($row->waktu_dikembalikan != 0) {
                        $lcwaktu_dikembalikan = date("d-m-Y H:i:s", $row->waktu_dikembalikan);
                    }
                    $tempdata = array(
                        "id_barang" => $row->id_barang,
                        "seqno" => $row->seqno,
                        "nama" => $row->nama,
                        "alamat1" => $row->alamat1,
                        "alamat2" => $row->alamat2,
                        "alamat3" => $row->alamat3,
                        "kota" => $row->kota,
                        "type" => $row->type,
                        "serv_type" => $row->serv_type,
                        "harga" => $row->harga,
                        "id_statusshipp" => $row->id_statusshipp,
                        "id_stati" => $row->id_stati,
                        "id_statret" => $row->id_statret,
                        "sts_penerima" => $row->statiket,
                        "penerima" => $row->penerima,
                        "sts_tolak" => $row->statretket,
                        "catatan" => $row->catatan,
                        "waktu_ambil" => $row->waktu_ambil != "" ? date("d-m-Y H:i:s", $row->waktu_ambil) : "",
                        "waktu_diterima" => $lcwaktu_diterima,
                        "waktu_dikembalikan" => $lcwaktu_dikembalikan
                    );

//                    array_push($arre, $tempdata);
                }
            }
        }

        $result = array("status" => 200, "message" => $message, "dokumen" => $tempdata);
        $this->authmodel->show_response($result);
    }

    //put your code here
}
