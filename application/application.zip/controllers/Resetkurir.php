<?php
require APPPATH . '/libraries/REST_Controller.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Resetkurir
 *
 * @author user
 */
class Resetkurir extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->library('helper');
        $this->load->model('accountmodel');
        $this->load->model('authmodel');
    }
    
     function index_post() {

        $clientid = $this->post('clientid');
        if (empty($clientid))
            $clientid = 0;

        $token = $this->post('token');
        if (empty($token))
            $token = '';

        $newpass = $this->post('newpass');
        if (empty($newpass))
            $newpass = '';


        $clientid = $this->helper->clearInt($clientid);

//        $newpass = $this->helper->clearText($newpass);

        if ($clientid != CLIENT_ID) {

            $this->helpel->printError(ERROR_UNKNOWN, CLIENT_ID + " Error client Id.");
        }

        $getidfromtoken = $this->authmodel->tokentoid($token);
        $message = FALSE;

        if ($getidfromtoken != 0 && $newpass != "") {
//            $message =  "okeh dah ada token nya ... !";
            $message = $this->authmodel->resetpass($getidfromtoken,$newpass);
            
        }

        $result = array("status" => 200, "message" => $message);
        $this->authmodel->show_response($result);
    }

}
